package com.example.parhausprj;

public interface ParkhausIF {
    void setOpeningHours(String openingHours);
    String getOpeningHours();


}
